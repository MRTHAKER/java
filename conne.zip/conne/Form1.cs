﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlServerCe;

namespace conne
{
    public partial class Form1 : Form
    {
        SqlCeCommand cmd;
        SqlCeConnection con;

        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            con = new SqlCeConnection(@"Data Source=c:\users\student-35\documents\visual studio 2010\Projects\conne\conne\Database69.sdf");
            con.Open();
            string gen="";
            if(radioButton1.Checked)
            {
                gen="male";
            }
            else
            {
                gen="female";
            }
            string s="insert into student values(@name,@id,@gender,@course)";
            cmd=new SqlCeCommand(s,con);
            cmd.Parameters.AddWithValue("@name",textBox1.Text.ToString());
            cmd.Parameters.AddWithValue("@id",Convert.ToInt32(textBox2.Text));
            cmd.Parameters.AddWithValue("@gender", gen);
            cmd.Parameters.AddWithValue("@course", comboBox1.Text.ToString());

            int ans = cmd.ExecuteNonQuery();
            if (ans > 0)
            {
                MessageBox.Show("Inserted");
                textBox1.Text = "";
                textBox2.Text = "";
                radioButton1.Checked = true;
                comboBox1.SelectedIndex = 0;
            }
            else
            {
                MessageBox.Show("Error");
            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            con = new SqlCeConnection(@"Data Source=c:\users\student-35\documents\visual studio 2010\Projects\conne\conne\Database69.sdf");
            con.Open();

            string s = "delete from student where id=(@id)";
            cmd = new SqlCeCommand(s, con);
            cmd.Parameters.AddWithValue("@id",Convert.ToInt32(textBox2.Text));
            int ans = cmd.ExecuteNonQuery();
            if (ans > 0)
            {
                MessageBox.Show("Deleted");
            }
            else
            {
                MessageBox.Show("Error");
            }


        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            radioButton1.Checked = true;
            comboBox1.SelectedIndex = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con = new SqlCeConnection(@"Data Source=c:\users\student-35\documents\visual studio 2010\Projects\conne\conne\Database69.sdf");
            con.Open();
          
            string gen = "";
            if (radioButton1.Checked)
            {
                gen = "male";
            }
            else
            {
                gen = "female";
            }

            string u = "update student set name='"+textBox1.Text+"',gender='"+gen +"',course='" +comboBox1.Text+"' where id="+Convert.ToInt32(textBox2.Text) +" ";
            cmd = new SqlCeCommand(u, con);
            int ans = cmd.ExecuteNonQuery();
            if (ans > 0)
            {
                MessageBox.Show("Updated");
                textBox1.Text = "";
                textBox2.Text = "";
                radioButton1.Checked = true;
                comboBox1.SelectedIndex = 0;
                con.Close();
            }
            else
            {
                MessageBox.Show("Error");
            }
        }
    }
}
